import { useCallback, useRef, useState } from 'react';
import {
  Upload as UploadIcon,
  FileSpreadsheet,
  FileText,
  CheckCircle2,
  XCircle,
  Loader2,
  Trash2,
  X,
} from 'lucide-react';
import { parseFile } from '@/lib/fileParser';
import { detectIssues } from '@/lib/dataQuality';
import { supabase } from '@/lib/supabase';
import type { Page } from '@/components/Sidebar';
import type { Dataset, DataQualityIssue } from '@/lib/types';

interface UploadProps {
  onReload: () => void;
  onNavigate: (page: Page) => void;
  datasets: Dataset[];
}

interface UploadProgress {
  filename: string;
  status: 'parsing' | 'saving' | 'done' | 'error';
  error?: string;
}

const MAX_SAMPLE_ROWS = 200;

export function Upload({ onReload, onNavigate, datasets }: UploadProps) {
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState<UploadProgress[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(
    async (files: FileList) => {
      const fileArr = Array.from(files);
      setProgress(fileArr.map((f) => ({ filename: f.name, status: 'parsing' })));

      for (let i = 0; i < fileArr.length; i++) {
        const file = fileArr[i];
        try {
          setProgress((prev) =>
            prev.map((p, idx) => (idx === i ? { ...p, status: 'parsing' } : p)),
          );

          const parsed = await parseFile(file);

          setProgress((prev) =>
            prev.map((p, idx) => (idx === i ? { ...p, status: 'saving' } : p)),
          );

          const sampleRows = parsed.rows.slice(0, MAX_SAMPLE_ROWS);
          const { data: dsRow, error: dsErr } = await supabase
            .from('datasets')
            .insert({
              filename: parsed.filename,
              file_type: parsed.fileType,
              row_count: parsed.rowCount,
              column_count: parsed.columnCount,
              columns: parsed.columns,
              sheet_name: parsed.sheetName,
              status: 'analyzed',
              file_size: parsed.fileSize,
              content: sampleRows,
            })
            .select()
            .single();

          if (dsErr) throw dsErr;

          const dsId = (dsRow as Dataset).id;
          const detected = detectIssues(parsed);
          if (detected.length > 0) {
            const issueRows = detected.map((d) => ({
              dataset_id: dsId,
              type: d.type,
              severity: d.severity,
              title: d.title,
              explanation: d.explanation,
              affected_column: d.affected_column,
              suggested_action: d.suggested_action,
            }));
            await supabase.from('data_quality_issues').insert(issueRows);
          }

          setProgress((prev) =>
            prev.map((p, idx) => (idx === i ? { ...p, status: 'done' } : p)),
          );
        } catch (err) {
          setProgress((prev) =>
            prev.map((p, idx) =>
              idx === i ? { ...p, status: 'error', error: (err as Error).message } : p,
            ),
          );
        }
      }

      onReload();
    },
    [onReload],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      if (e.dataTransfer.files.length > 0) {
        handleFiles(e.dataTransfer.files);
      }
    },
    [handleFiles],
  );

  const handleDelete = async (id: string) => {
    await supabase.from('datasets').delete().eq('id', id);
    onReload();
  };

  const clearProgress = () => setProgress([]);

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Upload your datasets</h1>
        <p className="text-slate-500 mt-1">
          Upload CSV or Excel files to begin analyzing your data.
        </p>
      </div>

      {/* Drop zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-2xl p-10 sm:p-14 text-center cursor-pointer transition-all ${
          dragging
            ? 'border-blue-500 bg-blue-50'
            : 'border-slate-300 bg-white hover:border-blue-400 hover:bg-slate-50'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".csv,.xlsx,.xls,.txt"
          className="hidden"
          onChange={(e) => {
            if (e.target.files) handleFiles(e.target.files);
            e.target.value = '';
          }}
        />
        <div className={`w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center transition-colors ${
          dragging ? 'bg-blue-100' : 'bg-slate-100'
        }`}>
          <UploadIcon size={28} className={dragging ? 'text-blue-600' : 'text-slate-400'} />
        </div>
        <p className="text-base font-medium text-slate-700">
          Drag and drop files here, or click to browse
        </p>
        <p className="text-sm text-slate-400 mt-1">
          Supports CSV, XLSX, XLS · Multiple files allowed
        </p>
      </div>

      {/* Upload progress */}
      {progress.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-slate-700">Upload Progress</h2>
            <button
              onClick={clearProgress}
              className="text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X size={16} />
            </button>
          </div>
          <div className="space-y-3">
            {progress.map((p, idx) => (
              <div key={idx} className="flex items-center gap-3 text-sm">
                {p.status === 'parsing' || p.status === 'saving' ? (
                  <Loader2 size={18} className="text-blue-500 animate-spin flex-shrink-0" />
                ) : p.status === 'done' ? (
                  <CheckCircle2 size={18} className="text-emerald-500 flex-shrink-0" />
                ) : (
                  <XCircle size={18} className="text-red-500 flex-shrink-0" />
                )}
                <span className="text-slate-700 flex-1 truncate">{p.filename}</span>
                <span className={`text-xs ${
                  p.status === 'done' ? 'text-emerald-600' :
                  p.status === 'error' ? 'text-red-600' :
                  'text-blue-600'
                }`}>
                  {p.status === 'parsing' ? 'Analyzing...' :
                   p.status === 'saving' ? 'Saving...' :
                   p.status === 'done' ? 'Analyzed' :
                   p.error ?? 'Error'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Uploaded files list */}
      {datasets.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-slate-700 mb-3">
            Uploaded Files ({datasets.length})
          </h2>
          <div className="space-y-3">
            {datasets.map((ds) => (
              <div
                key={ds.id}
                className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex items-center gap-4"
              >
                <div className="w-11 h-11 rounded-lg bg-slate-100 flex items-center justify-center flex-shrink-0">
                  {ds.file_type === 'xlsx' ? (
                    <FileSpreadsheet size={22} className="text-emerald-600" />
                  ) : (
                    <FileText size={22} className="text-blue-600" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-semibold text-slate-900 truncate">{ds.filename}</h3>
                    {ds.sheet_name && (
                      <span className="text-xs text-slate-400">· {ds.sheet_name}</span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {ds.row_count.toLocaleString()} rows · {ds.column_count} columns
                    {' · '}{(ds.file_size / 1024).toFixed(0)} KB
                  </p>
                </div>
                <div className="flex items-center gap-3 flex-shrink-0">
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                    <CheckCircle2 size={14} />
                    Analyzed
                  </span>
                  <button
                    onClick={() => handleDelete(ds.id)}
                    className="text-slate-300 hover:text-red-500 transition-colors"
                    aria-label="Delete file"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-3">
            <button
              onClick={() => onNavigate('quality')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors"
            >
              View Data Quality
            </button>
            <button
              onClick={() => onNavigate('ask')}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              Start Asking Questions
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
