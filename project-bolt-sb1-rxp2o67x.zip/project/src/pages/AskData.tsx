import { useRef, useState, useEffect } from 'react';
import {
  Send,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Loader2,
  MessageSquare,
  Database,
} from 'lucide-react';
import { analyzeQuestion, questionToRecord } from '@/lib/analysisEngine';
import { supabase } from '@/lib/supabase';
import type { Dataset, Question, VerificationStatus } from '@/lib/types';
import { CodeBlock } from '@/components/CodeBlock';
import type { Page } from '@/components/Sidebar';

interface AskDataProps {
  datasets: Dataset[];
  questions: Question[];
  onReload: () => void;
  onNavigate: (page: Page) => void;
}

const EXAMPLE_QUESTIONS = [
  'What was the total revenue in 2025?',
  'Which product generated the highest profit?',
  'What was the average order value?',
  'Compare sales between January and February.',
  'Which region had the highest growth?',
];

export function AskData({ datasets, questions, onReload, onNavigate }: AskDataProps) {
  const [input, setInput] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [questions, analyzing]);

  const handleAsk = async (questionText?: string) => {
    const q = (questionText ?? input).trim();
    if (!q || analyzing) return;

    setAnalyzing(true);
    setInput('');

    const result = analyzeQuestion(q, datasets);
    const record = questionToRecord(q, result);

    await supabase.from('questions').insert(record);
    onReload();
    setAnalyzing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-2rem)] max-h-[calc(100vh-2rem)]">
      <div className="mb-4">
        <h1 className="text-2xl font-bold text-slate-900">Ask anything about your data</h1>
        <p className="text-slate-500 mt-1">
          Every answer includes verifiable Python code you can run independently.
        </p>
      </div>

      {datasets.length === 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4 flex items-center gap-3">
          <AlertTriangle size={20} className="text-amber-600 flex-shrink-0" />
          <div className="flex-1 text-sm text-amber-700">
            No datasets uploaded yet. Upload data first to start asking questions.
          </div>
          <button
            onClick={() => onNavigate('upload')}
            className="text-sm font-medium text-amber-700 hover:text-amber-900 underline"
          >
            Upload Data
          </button>
        </div>
      )}

      {/* Chat area */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-6 space-y-4"
      >
        {questions.length === 0 && !analyzing && (
          <div className="text-center py-12">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 mx-auto mb-4 flex items-center justify-center">
              <MessageSquare size={28} className="text-blue-500" />
            </div>
            <h3 className="text-base font-semibold text-slate-700">Start the conversation</h3>
            <p className="text-sm text-slate-400 mt-1 mb-6">
              Ask a question about your data in plain English
            </p>
            <div className="flex flex-wrap gap-2 justify-center max-w-2xl mx-auto">
              {EXAMPLE_QUESTIONS.map((q) => (
                <button
                  key={q}
                  onClick={() => handleAsk(q)}
                  disabled={datasets.length === 0}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {questions.map((q) => (
          <ChatMessage key={q.id} question={q} />
        ))}

        {analyzing && (
          <div className="flex items-center gap-3 text-sm text-slate-500 pl-1">
            <Loader2 size={18} className="text-blue-500 animate-spin" />
            <span>Analyzing your data and generating verification code...</span>
          </div>
        )}
      </div>

      {/* Input area */}
      <div className="mt-4">
        <div className="flex items-center gap-3 mb-2 flex-wrap">
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <Database size={12} />
            {datasets.length} {datasets.length === 1 ? 'dataset' : 'datasets'} loaded
          </span>
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask a question about your data..."
            className="flex-1 px-4 py-3 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            onClick={() => handleAsk()}
            disabled={!input.trim() || analyzing || datasets.length === 0}
            className="inline-flex items-center gap-2 px-5 py-3 bg-blue-600 text-white rounded-xl font-medium text-sm hover:bg-blue-700 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed"
          >
            <Send size={16} />
            Analyze
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatMessage({ question }: { question: Question }) {
  const statusMeta: Record<VerificationStatus, { icon: typeof ShieldCheck; color: string; bg: string; label: string }> = {
    verified: { icon: ShieldCheck, color: 'text-emerald-600', bg: 'bg-emerald-50', label: 'Verified' },
    unverified: { icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Unverified' },
    cannot_determine: { icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', label: 'Cannot Determine' },
    pending: { icon: Loader2, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Pending' },
  };

  const sm = statusMeta[question.verification_status];
  const StatusIcon = sm.icon;
  const isCannotDetermine = question.verification_status === 'cannot_determine';

  return (
    <div className="space-y-3">
      {/* User question */}
      <div className="flex justify-end">
        <div className="max-w-[80%] bg-blue-600 text-white rounded-2xl rounded-tr-md px-4 py-2.5 text-sm">
          {question.question_text}
        </div>
      </div>

      {/* AI answer */}
      <div className="flex gap-3">
        <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
          <Sparkles size={16} className="text-blue-600" />
        </div>
        <div className="flex-1 min-w-0 space-y-3">
          {/* Answer */}
          <div className={`rounded-2xl rounded-tl-md border p-4 ${
            isCannotDetermine
              ? 'bg-amber-50 border-amber-200'
              : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${sm.color} ${sm.bg} px-2.5 py-1 rounded-full`}>
                <StatusIcon size={12} />
                {sm.label}
              </span>
              {question.data_sources.length > 0 && (
                <span className="text-xs text-slate-400">
                  via {question.data_sources.join(', ')}
                </span>
              )}
            </div>
            <div className={`text-xl font-bold ${
              isCannotDetermine ? 'text-amber-800' : 'text-slate-900'
            }`}>
              {question.answer}
            </div>
            {question.explanation && (
              <p className="text-sm text-slate-600 mt-2 leading-relaxed">{question.explanation}</p>
            )}
          </div>

          {/* Code */}
          {question.code && (
            <CodeBlock code={question.code} />
          )}
        </div>
      </div>
    </div>
  );
}
