import {
  ShieldCheck,
  AlertTriangle,
  FileCode2,
  Database,
  HelpCircle,
  Lightbulb,
  XCircle,
} from 'lucide-react';
import type { Question, VerificationStatus } from '@/lib/types';
import { CodeBlock } from '@/components/CodeBlock';

interface VerificationProps {
  questions: Question[];
}

export function Verification({ questions }: VerificationProps) {
  const verified = questions.filter((q) => q.verification_status === 'verified');
  const unverified = questions.filter((q) => q.verification_status !== 'verified');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Verification</h1>
        <p className="text-slate-500 mt-1">
          Every answer is paired with executable Python code for independent verification.
        </p>
      </div>

      {/* Summary bar */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex items-center gap-6">
        <div className="flex items-center gap-2">
          <ShieldCheck size={20} className="text-emerald-600" />
          <span className="text-sm font-semibold text-slate-700">{verified.length} Verified</span>
        </div>
        <div className="w-px h-6 bg-slate-200" />
        <div className="flex items-center gap-2">
          <AlertTriangle size={20} className="text-amber-600" />
          <span className="text-sm font-semibold text-slate-700">{unverified.length} Unverified</span>
        </div>
        <div className="w-px h-6 bg-slate-200" />
        <div className="flex items-center gap-2">
          <HelpCircle size={20} className="text-slate-400" />
          <span className="text-sm text-slate-500">{questions.length} Total Questions</span>
        </div>
      </div>

      {questions.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 mx-auto mb-4 flex items-center justify-center">
            <ShieldCheck size={28} className="text-slate-400" />
          </div>
          <h3 className="text-base font-semibold text-slate-700">No verification records yet</h3>
          <p className="text-sm text-slate-400 mt-1">
            Ask questions on the Ask Data page to see verification details here.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {questions.map((q) => (
            <VerificationCard key={q.id} question={q} />
          ))}
        </div>
      )}
    </div>
  );
}

function VerificationCard({ question }: { question: Question }) {
  const statusMeta: Record<VerificationStatus, { icon: typeof ShieldCheck; label: string; color: string; bg: string }> = {
    verified: { icon: ShieldCheck, label: 'Verified', color: 'text-emerald-600', bg: 'bg-emerald-50' },
    unverified: { icon: AlertTriangle, label: 'Unverified', color: 'text-amber-600', bg: 'bg-amber-50' },
    cannot_determine: { icon: XCircle, label: 'Cannot Determine', color: 'text-amber-600', bg: 'bg-amber-50' },
    pending: { icon: AlertTriangle, label: 'Pending', color: 'text-blue-600', bg: 'bg-blue-50' },
  };

  const sm = statusMeta[question.verification_status];
  const StatusIcon = sm.icon;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <HelpCircle size={18} className="text-slate-400" />
          <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">Question</span>
        </div>
        <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${sm.color} ${sm.bg} px-2.5 py-1 rounded-full`}>
          <StatusIcon size={12} />
          {sm.label}
        </span>
      </div>

      <div className="px-5 py-4 space-y-4">
        {/* Question text */}
        <p className="text-base font-semibold text-slate-900">{question.question_text}</p>

        {/* Answer */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-slate-50 rounded-xl p-4">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-1">Answer</div>
            <div className={`text-lg font-bold ${
              question.verification_status === 'cannot_determine' ? 'text-amber-700' : 'text-slate-900'
            }`}>
              {question.answer}
            </div>
          </div>

          <div className="bg-slate-50 rounded-xl p-4">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-1 flex items-center gap-1">
              <Database size={11} />
              Data Used
            </div>
            <div className="text-sm text-slate-700">
              {question.data_sources.length > 0 ? question.data_sources.join(', ') : 'N/A'}
            </div>
          </div>

          <div className="bg-slate-50 rounded-xl p-4">
            <div className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-1">Date</div>
            <div className="text-sm text-slate-700">
              {new Date(question.created_at).toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </div>
          </div>
        </div>

        {/* Explanation */}
        {question.explanation && (
          <div className="flex items-start gap-2 text-sm bg-blue-50 rounded-lg p-3">
            <Lightbulb size={16} className="text-blue-500 flex-shrink-0 mt-0.5" />
            <span className="text-slate-700 leading-relaxed">{question.explanation}</span>
          </div>
        )}

        {/* Code */}
        {question.code && (
          <div>
            <div className="flex items-center gap-2 mb-2">
              <FileCode2 size={16} className="text-slate-400" />
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">
                Verification Code
              </span>
            </div>
            <CodeBlock code={question.code} />
          </div>
        )}

        {/* Error */}
        {question.error_message && !question.code && (
          <div className="flex items-start gap-2 text-sm bg-red-50 rounded-lg p-3">
            <AlertTriangle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
            <span className="text-red-700 leading-relaxed">{question.error_message}</span>
          </div>
        )}
      </div>
    </div>
  );
}
