import type { DataQualityIssue, Dataset } from '@/lib/types';
import { ISSUE_META, SEVERITY_META } from '@/lib/dataQuality';
import {
  Copy,
  AlertCircle,
  DollarSign,
  Calendar,
  CheckCircle,
  Link,
  Lightbulb,
  AlertTriangle,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const ICON_MAP: Record<string, LucideIcon> = {
  Copy,
  AlertCircle,
  DollarSign,
  Calendar,
  CheckCircle,
  Link,
};

interface DataQualityProps {
  issues: DataQualityIssue[];
  datasets: Dataset[];
}

const SEVERITY_ORDER = { high: 0, medium: 1, low: 2, info: 3 };

export function DataQuality({ issues, datasets }: DataQualityProps) {
  const sorted = [...issues].sort(
    (a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity],
  );

  const highCount = issues.filter((i) => i.severity === 'high').length;
  const mediumCount = issues.filter((i) => i.severity === 'medium').length;
  const infoCount = issues.filter((i) => i.severity === 'info').length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Data Quality</h1>
        <p className="text-slate-500 mt-1">
          Detected problems and inconsistencies across your uploaded datasets.
        </p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
          <div className="text-2xl font-bold text-red-600">{highCount}</div>
          <div className="text-xs text-slate-500 mt-1">High Severity</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
          <div className="text-2xl font-bold text-amber-600">{mediumCount}</div>
          <div className="text-xs text-slate-500 mt-1">Medium Severity</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
          <div className="text-2xl font-bold text-emerald-600">{infoCount}</div>
          <div className="text-xs text-slate-500 mt-1">All Clear</div>
        </div>
      </div>

      {issues.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 mx-auto mb-4 flex items-center justify-center">
            <AlertTriangle size={28} className="text-slate-400" />
          </div>
          <h3 className="text-base font-semibold text-slate-700">No data quality issues detected yet</h3>
          <p className="text-sm text-slate-400 mt-1">
            Upload datasets to automatically detect duplicates, missing values, and more.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sorted.map((issue) => {
            const meta = ISSUE_META[issue.type];
            const sev = SEVERITY_META[issue.severity];
            const Icon = ICON_MAP[meta.icon] ?? AlertCircle;

            const sevColor: Record<string, { bg: string; text: string; border: string }> = {
              high: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
              medium: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
              low: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
              info: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
            };
            const sc = sevColor[issue.severity];

            const iconBg: Record<string, string> = {
              high: 'bg-red-100',
              medium: 'bg-amber-100',
              low: 'bg-blue-100',
              info: 'bg-emerald-100',
            };
            const iconText: Record<string, string> = {
              high: 'text-red-600',
              medium: 'text-amber-600',
              low: 'text-blue-600',
              info: 'text-emerald-600',
            };

            return (
              <div
                key={issue.id}
                className={`bg-white rounded-xl border ${sc.border} shadow-sm p-5`}
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-10 h-10 rounded-lg ${iconBg[issue.severity]} flex items-center justify-center flex-shrink-0`}>
                    <Icon size={20} className={iconText[issue.severity]} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm font-semibold text-slate-900">{issue.title}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${sc.bg} ${sc.text}`}>
                        {sev.label}
                      </span>
                    </div>
                    {issue.affected_column && (
                      <span className="text-xs text-slate-400 mt-0.5 block">
                        Column: {issue.affected_column}
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed mb-3">{issue.explanation}</p>
                <div className="flex items-start gap-2 text-xs bg-slate-50 rounded-lg p-3">
                  <Lightbulb size={14} className="text-amber-500 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-600">{issue.suggested_action}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Dataset schemas */}
      {datasets.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-slate-700 mb-3">Dataset Schemas</h2>
          <div className="space-y-3">
            {datasets.map((ds) => (
              <div key={ds.id} className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
                <h3 className="text-sm font-semibold text-slate-900 mb-3">{ds.filename}</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="text-left py-2 px-3 font-medium text-slate-500">Column</th>
                        <th className="text-left py-2 px-3 font-medium text-slate-500">Type</th>
                        <th className="text-left py-2 px-3 font-medium text-slate-500">Sample</th>
                        <th className="text-right py-2 px-3 font-medium text-slate-500">Missing</th>
                        <th className="text-right py-2 px-3 font-medium text-slate-500">Unique</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ds.columns.map((col) => (
                        <tr key={col.name} className="border-b border-slate-100 last:border-0">
                          <td className="py-2 px-3 font-medium text-slate-700">{col.name}</td>
                          <td className="py-2 px-3">
                            <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                              col.type === 'number' ? 'bg-blue-50 text-blue-600' :
                              col.type === 'date' ? 'bg-purple-50 text-purple-600' :
                              col.type === 'boolean' ? 'bg-emerald-50 text-emerald-600' :
                              col.type === 'mixed' ? 'bg-amber-50 text-amber-600' :
                              'bg-slate-100 text-slate-500'
                            }`}>
                              {col.type}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-400 max-w-[200px] truncate">{col.sample}</td>
                          <td className="py-2 px-3 text-right text-slate-600">
                            {col.missingCount > 0 ? (
                              <span className="text-amber-600">{col.missingCount}</span>
                            ) : (
                              <span className="text-slate-300">0</span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-right text-slate-600">{col.uniqueCount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
