import {
  FileText,
  Table2,
  AlertTriangle,
  ShieldCheck,
  Upload as UploadIcon,
  MessageSquare,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { StatCard } from '@/components/StatCard';
import type { Page } from '@/components/Sidebar';

interface DashboardProps {
  fileCount: number;
  tableCount: number;
  issueCount: number;
  verifiedCount: number;
  onNavigate: (page: Page) => void;
}

export function Dashboard({
  fileCount,
  tableCount,
  issueCount,
  verifiedCount,
  onNavigate,
}: DashboardProps) {
  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="relative px-6 py-8 sm:px-8 sm:py-10">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl opacity-60 -translate-y-1/3 translate-x-1/4" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-medium mb-4">
              <Sparkles size={14} />
              Agentic GenAI · Data Analytics · Code Generation · Verification
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
              Your Verified AI Data Analyst
            </h1>
            <p className="text-slate-600 max-w-2xl text-sm sm:text-base leading-relaxed">
              Every numerical answer is backed by executable verification code.
              Upload your data, ask questions in plain English, and independently
              verify every calculation.
            </p>
            <div className="flex flex-wrap gap-3 mt-6">
              <button
                onClick={() => onNavigate('upload')}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg font-medium text-sm hover:bg-blue-700 transition-colors shadow-sm"
              >
                <UploadIcon size={16} />
                Upload Data
              </button>
              <button
                onClick={() => onNavigate('ask')}
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-white text-slate-700 border border-slate-300 rounded-lg font-medium text-sm hover:bg-slate-50 transition-colors"
              >
                <MessageSquare size={16} />
                Ask a Question
                <ArrowRight size={14} className="ml-0.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={FileText} label="Files Uploaded" value={fileCount} color="blue" />
        <StatCard icon={Table2} label="Tables Detected" value={tableCount} color="emerald" />
        <StatCard icon={AlertTriangle} label="Data Quality Issues" value={issueCount} color="amber" />
        <StatCard icon={ShieldCheck} label="Verified Answers" value={verifiedCount} color="blue" />
      </div>

      {/* How it works */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <h2 className="text-lg font-bold text-slate-900 mb-1">How It Works</h2>
        <p className="text-sm text-slate-500 mb-6">The proof-carrying verification pipeline</p>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[
            { n: '1', t: 'Upload', d: 'Drop in CSV or Excel files', icon: UploadIcon },
            { n: '2', t: 'Inspect', d: 'Auto-detect quality issues', icon: AlertTriangle },
            { n: '3', t: 'Ask', d: 'Natural language questions', icon: MessageSquare },
            { n: '4', t: 'Generate', d: 'Python code per answer', icon: FileText },
            { n: '5', t: 'Verify', d: 'Answer shown only if verified', icon: ShieldCheck },
          ].map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.n} className="relative">
                <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center mb-3">
                  <Icon size={20} className="text-blue-600" />
                </div>
                <div className="text-xs font-medium text-blue-600 mb-1">Step {step.n}</div>
                <h3 className="text-sm font-semibold text-slate-900 mb-1">{step.t}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{step.d}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
