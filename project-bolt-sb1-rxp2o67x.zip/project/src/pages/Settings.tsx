import { useState } from 'react';
import { Settings as SettingsIcon, Shield, Code2, Database, Check } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export function Settings() {
  const [strictMode, setStrictMode] = useState(true);
  const [autoVerify, setAutoVerify] = useState(true);
  const [showCode, setShowCode] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    await supabase.from('settings').upsert({
      key: 'app_settings',
      value: { strictMode, autoVerify, showCode },
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  const handlePurge = async () => {
    await supabase.from('questions').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    await supabase.from('data_quality_issues').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    await supabase.from('datasets').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
        <p className="text-slate-500 mt-1">Configure verification behavior and display preferences.</p>
      </div>

      {/* Verification Settings */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <Shield size={18} className="text-blue-600" />
          <h2 className="text-sm font-semibold text-slate-900">Verification</h2>
        </div>
        <div className="space-y-4">
          <ToggleRow
            label="Strict Verification Mode"
            description="Only show answers when verification code produces a matching result."
            value={strictMode}
            onChange={setStrictMode}
          />
          <ToggleRow
            label="Auto-Verify on Ask"
            description="Automatically run verification after generating each answer."
            value={autoVerify}
            onChange={setAutoVerify}
          />
        </div>
      </div>

      {/* Display Settings */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <Code2 size={18} className="text-blue-600" />
          <h2 className="text-sm font-semibold text-slate-900">Display</h2>
        </div>
        <div className="space-y-4">
          <ToggleRow
            label="Show Verification Code"
            description="Display the generated Python code alongside each answer."
            value={showCode}
            onChange={setShowCode}
          />
        </div>
      </div>

      {/* Data Management */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <Database size={18} className="text-blue-600" />
          <h2 className="text-sm font-semibold text-slate-900">Data Management</h2>
        </div>
        <button
          onClick={handlePurge}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-red-600 border border-red-200 rounded-lg hover:bg-red-50 transition-colors"
        >
          <SettingsIcon size={16} />
          Clear All Data
        </button>
        <p className="text-xs text-slate-400 mt-2">
          Removes all uploaded datasets, quality issues, and question history. This cannot be undone.
        </p>
      </div>

      {/* Save */}
      <div className="flex items-center gap-3">
        <button
          onClick={handleSave}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg font-medium text-sm hover:bg-blue-700 transition-colors"
        >
          {saved ? <Check size={16} /> : null}
          {saved ? 'Saved' : 'Save Settings'}
        </button>
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  description,
  value,
  onChange,
}: {
  label: string;
  description: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex-1">
        <div className="text-sm font-medium text-slate-700">{label}</div>
        <div className="text-xs text-slate-400 mt-0.5">{description}</div>
      </div>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${
          value ? 'bg-blue-600' : 'bg-slate-300'
        }`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm transition-transform ${
            value ? 'translate-x-5' : 'translate-x-0'
          }`}
        />
      </button>
    </div>
  );
}
