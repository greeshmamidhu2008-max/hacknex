import { History as HistoryIcon, ShieldCheck, AlertTriangle, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Question, VerificationStatus } from '@/lib/types';

interface HistoryProps {
  questions: Question[];
  onReload: () => void;
}

export function History({ questions, onReload }: HistoryProps) {
  const handleDelete = async (id: string) => {
    await supabase.from('questions').delete().eq('id', id);
    onReload();
  };

  const handleClearAll = async () => {
    await supabase.from('questions').delete().neq('id', '00000000-0000-0000-0000-000000000000');
    onReload();
  };

  const statusColor: Record<VerificationStatus, string> = {
    verified: 'bg-emerald-100 text-emerald-700',
    unverified: 'bg-amber-100 text-amber-700',
    cannot_determine: 'bg-amber-100 text-amber-700',
    pending: 'bg-blue-100 text-blue-700',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">History</h1>
          <p className="text-slate-500 mt-1">All questions asked and their verification status.</p>
        </div>
        {questions.length > 0 && (
          <button
            onClick={handleClearAll}
            className="inline-flex items-center gap-2 px-3 py-2 text-sm text-slate-500 hover:text-red-600 transition-colors"
          >
            <Trash2 size={16} />
            Clear All
          </button>
        )}
      </div>

      {questions.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 mx-auto mb-4 flex items-center justify-center">
            <HistoryIcon size={28} className="text-slate-400" />
          </div>
          <h3 className="text-base font-semibold text-slate-700">No history yet</h3>
          <p className="text-sm text-slate-400 mt-1">
            Questions you ask will appear here with their verification status.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50">
                <th className="text-left py-3 px-4 font-medium text-slate-500">Question</th>
                <th className="text-left py-3 px-4 font-medium text-slate-500 hidden sm:table-cell">Answer</th>
                <th className="text-left py-3 px-4 font-medium text-slate-500">Status</th>
                <th className="text-left py-3 px-4 font-medium text-slate-500 hidden md:table-cell">Date</th>
                <th className="w-10" />
              </tr>
            </thead>
            <tbody>
              {questions.map((q) => (
                <tr key={q.id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-4 text-slate-900 font-medium max-w-xs truncate">{q.question_text}</td>
                  <td className="py-3 px-4 text-slate-600 hidden sm:table-cell max-w-xs truncate">{q.answer}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full ${statusColor[q.verification_status]}`}>
                      {q.verification_status === 'verified' ? <ShieldCheck size={12} /> : <AlertTriangle size={12} />}
                      {q.verification_status === 'cannot_determine' ? 'Cannot Determine' : q.verification_status.charAt(0).toUpperCase() + q.verification_status.slice(1)}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 text-xs hidden md:table-cell">
                    {new Date(q.created_at).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </td>
                  <td className="py-3 px-2">
                    <button
                      onClick={() => handleDelete(q.id)}
                      className="text-slate-300 hover:text-red-500 transition-colors p-1"
                      aria-label="Delete question"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
