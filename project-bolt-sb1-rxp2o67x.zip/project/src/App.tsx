import { useState } from 'react';
import { Sidebar, type Page } from '@/components/Sidebar';
import { Dashboard } from '@/pages/Dashboard';
import { Upload } from '@/pages/Upload';
import { AskData } from '@/pages/AskData';
import { Verification } from '@/pages/Verification';
import { DataQuality } from '@/pages/DataQuality';
import { History } from '@/pages/History';
import { Settings } from '@/pages/Settings';
import { useStore } from '@/lib/useStore';
import { Loader2 } from 'lucide-react';

function App() {
  const [page, setPage] = useState<Page>('dashboard');
  const { datasets, issues, questions, loading, reload } = useStore();

  const fileCount = datasets.length;
  const tableCount = datasets.length;
  const issueCount = issues.filter((i) => i.type !== 'consistent_data').length;
  const verifiedCount = questions.filter((q) => q.verification_status === 'verified').length;

  const handleNavigate = (p: Page) => setPage(p);

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar
        current={page}
        onNavigate={handleNavigate}
        fileCount={fileCount}
        issueCount={issueCount}
        questionCount={questions.length}
      />
      <main className="flex-1 min-w-0 overflow-x-hidden">
        <div className="p-6 sm:p-8 max-w-6xl mx-auto">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 size={24} className="text-blue-500 animate-spin" />
            </div>
          ) : (
            <>
              {page === 'dashboard' && (
                <Dashboard
                  fileCount={fileCount}
                  tableCount={tableCount}
                  issueCount={issueCount}
                  verifiedCount={verifiedCount}
                  onNavigate={handleNavigate}
                />
              )}
              {page === 'upload' && (
                <Upload onReload={reload} onNavigate={handleNavigate} datasets={datasets} />
              )}
              {page === 'ask' && (
                <AskData
                  datasets={datasets}
                  questions={questions}
                  onReload={reload}
                  onNavigate={handleNavigate}
                />
              )}
              {page === 'verification' && <Verification questions={questions} />}
              {page === 'quality' && <DataQuality issues={issues} datasets={datasets} />}
              {page === 'history' && <History questions={questions} onReload={reload} />}
              {page === 'settings' && <Settings />}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;
