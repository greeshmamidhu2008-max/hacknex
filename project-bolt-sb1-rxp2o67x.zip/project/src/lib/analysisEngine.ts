import type { Dataset, Question, VerificationStatus } from './types';

interface AnalysisResult {
  answer: string;
  answerNumeric: number | null;
  verificationStatus: VerificationStatus;
  explanation: string;
  dataSources: string[];
  code: string;
  errorMessage: string | null;
}

interface MatchResult {
  matched: boolean;
  result: AnalysisResult;
}

function normalize(s: string): string {
  return s.toLowerCase().replace(/[_\s-]/g, '');
}

function findColumn(cols: string[], candidates: string[]): string | null {
  const normCols = cols.map((c) => ({ orig: c, norm: normalize(c) }));
  for (const cand of candidates) {
    const nc = normalize(cand);
    const found = normCols.find((c) => c.norm === nc);
    if (found) return found.orig;
  }
  for (const cand of candidates) {
    const nc = normalize(cand);
    const found = normCols.find((c) => c.norm.includes(nc) || nc.includes(c.norm));
    if (found) return found.orig;
  }
  return null;
}

function toNum(v: unknown): number {
  if (typeof v === 'number') return v;
  const s = String(v ?? '').replace(/[$,€£¥₹\s]/g, '').replace(/[A-Za-z]{3}/g, '');
  const n = Number(s);
  return isNaN(n) ? 0 : n;
}

function toDate(v: unknown): Date | null {
  if (v instanceof Date) return v;
  const s = String(v ?? '').trim();
  if (!s) return null;
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}

function formatNumber(n: number): string {
  if (Math.abs(n) >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  if (Math.abs(n) >= 1_000) return `$${(n / 1_000).toFixed(2)}K`;
  return `$${n.toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
}

function genCode(
  filenames: string[],
  fileVar: string,
  dateCol: string,
  year: number,
  valueCol: string,
  agg: string,
): string {
  const fileCall =
    filenames[0].endsWith('.xlsx')
      ? `pd.read_excel("${filenames[0]}")`
      : `pd.read_csv("${filenames[0]}")`;

  if (agg === 'sum') {
    return `import pandas as pd

${fileVar} = ${fileCall}

${fileVar}["${dateCol}"] = pd.to_datetime(${fileVar}["${dateCol}"])

result = ${fileVar}[
    ${fileVar}["${dateCol}"].dt.year == ${year}
]["${valueCol}"].sum()

print(result)`;
  }
  return `import pandas as pd

${fileVar} = ${fileCall}

${fileVar}["${dateCol}"] = pd.to_datetime(${fileVar}["${dateCol}"])

result = ${fileVar}[
    ${fileVar}["${dateCol}"].dt.year == ${year}
]["${valueCol}"].mean()

print(result)`;
}

function computeTotalRevenue(
  ds: Dataset,
  year: number | null,
): MatchResult | null {
  const cols = ds.columns.map((c) => c.name);
  const revCol = findColumn(cols, ['revenue', 'sales', 'amount', 'total', 'price', 'value']);
  const dateCol = findColumn(cols, ['date', 'orderdate', 'transactiondate', 'createdat', 'timestamp']);

  if (!revCol) return null;

  const rows = ds.content;
  let filteredRows = rows;
  let yearFilter = '';

  if (dateCol && year) {
    filteredRows = rows.filter((r) => {
      const d = toDate(r[dateCol]);
      return d && d.getFullYear() === year;
    });
    yearFilter = ` for year ${year}`;
  }

  const total = filteredRows.reduce((sum, r) => sum + toNum(r[revCol]), 0);
  const fileVar = ds.filename.replace(/[^a-zA-Z]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');
  const code = dateCol
    ? genCode([ds.filename], fileVar, dateCol, year ?? 0, revCol, 'sum')
    : `import pandas as pd

${fileVar} = pd.read_csv("${ds.filename}")

result = ${fileVar}["${revCol}"].sum()

print(result)`;

  return {
    matched: true,
    result: {
      answer: formatNumber(total),
      answerNumeric: total,
      verificationStatus: 'verified',
      explanation: `Summed the "${revCol}" column from ${ds.filename}${yearFilter}. The Python code on the right independently computes this total so you can verify the number.`,
      dataSources: [ds.filename],
      code,
      errorMessage: null,
    },
  };
}

function computeAverage(
  ds: Dataset,
  year: number | null,
): MatchResult | null {
  const cols = ds.columns.map((c) => c.name);
  const valCol = findColumn(cols, ['revenue', 'sales', 'amount', 'total', 'price', 'value', 'ordervalue']);
  const dateCol = findColumn(cols, ['date', 'orderdate', 'transactiondate', 'createdat']);

  if (!valCol) return null;

  const rows = ds.content;
  let filteredRows = rows;
  let yearFilter = '';

  if (dateCol && year) {
    filteredRows = rows.filter((r) => {
      const d = toDate(r[dateCol]);
      return d && d.getFullYear() === year;
    });
    yearFilter = ` for year ${year}`;
  }

  if (filteredRows.length === 0) {
    return {
      matched: true,
      result: {
        answer: 'N/A',
        answerNumeric: null,
        verificationStatus: 'cannot_determine',
        explanation: `No rows found${yearFilter} in ${ds.filename}. The dataset may not contain data for that period.`,
        dataSources: [ds.filename],
        code: '',
        errorMessage: 'No matching rows',
      },
    };
  }

  const avg = filteredRows.reduce((sum, r) => sum + toNum(r[valCol]), 0) / filteredRows.length;
  const fileVar = ds.filename.replace(/[^a-zA-Z]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');

  return {
    matched: true,
    result: {
      answer: formatNumber(avg),
      answerNumeric: avg,
      verificationStatus: 'verified',
      explanation: `Computed the mean of "${valCol}" from ${ds.filename}${yearFilter} across ${filteredRows.length} rows. The verification code reproduces this calculation.`,
      dataSources: [ds.filename],
      code: `import pandas as pd

${fileVar} = pd.read_csv("${ds.filename}")

${dateCol ? `${fileVar}["${dateCol}"] = pd.to_datetime(${fileVar}["${dateCol}"])\nresult = ${fileVar}[${fileVar}["${dateCol}"].dt.year == ${year}]["${valCol}"].mean()` : `result = ${fileVar}["${valCol}"].mean()`}

print(result)`,
      errorMessage: null,
    },
  };
}

function computeTopProduct(ds: Dataset): MatchResult | null {
  const cols = ds.columns.map((c) => c.name);
  const prodCol = findColumn(cols, ['product', 'productname', 'item', 'itemname', 'sku']);
  const revCol = findColumn(cols, ['revenue', 'sales', 'amount', 'total', 'profit', 'price']);

  if (!prodCol || !revCol) return null;

  const rows = ds.content;
  const byProduct = new Map<string, number>();
  for (const row of rows) {
    const p = String(row[prodCol] ?? 'Unknown');
    byProduct.set(p, (byProduct.get(p) ?? 0) + toNum(row[revCol]));
  }

  let topProduct = '';
  let topVal = -Infinity;
  for (const [k, v] of byProduct) {
    if (v > topVal) {
      topVal = v;
      topProduct = k;
    }
  }

  const fileVar = ds.filename.replace(/[^a-zA-Z]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');

  return {
    matched: true,
    result: {
      answer: `${topProduct} (${formatNumber(topVal)})`,
      answerNumeric: topVal,
      verificationStatus: 'verified',
      explanation: `Grouped ${ds.filename} by "${prodCol}" and summed "${revCol}". The product with the highest total is "${topProduct}".`,
      dataSources: [ds.filename],
      code: `import pandas as pd

${fileVar} = pd.read_csv("${ds.filename}")

grouped = ${fileVar}.groupby("${prodCol}")["${revCol}"].sum()

top = grouped.idxmax()
top_value = grouped.max()

print(f"{top}: {top_value}")`,
      errorMessage: null,
    },
  };
}

function computeCompareMonths(ds: Dataset, m1: number, m2: number, year: number | null): MatchResult | null {
  const cols = ds.columns.map((c) => c.name);
  const dateCol = findColumn(cols, ['date', 'orderdate', 'transactiondate']);
  const revCol = findColumn(cols, ['revenue', 'sales', 'amount', 'total', 'value']);

  if (!dateCol || !revCol) return null;

  const rows = ds.content;
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const sums = [0, 0];
  for (const row of rows) {
    const d = toDate(row[dateCol]);
    if (!d) continue;
    if (year && d.getFullYear() !== year) continue;
    if (d.getMonth() + 1 === m1) sums[0] += toNum(row[revCol]);
    if (d.getMonth() + 1 === m2) sums[1] += toNum(row[revCol]);
  }

  const diff = sums[0] - sums[1];
  const pct = sums[1] !== 0 ? ((diff / sums[1]) * 100).toFixed(1) : 'N/A';

  const fileVar = ds.filename.replace(/[^a-zA-Z]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');

  return {
    matched: true,
    result: {
      answer: `${monthNames[m1 - 1]}: ${formatNumber(sums[0])} vs ${monthNames[m2 - 1]}: ${formatNumber(sums[1])} (${diff >= 0 ? '+' : ''}${formatNumber(diff)}, ${pct}% change)`,
      answerNumeric: diff,
      verificationStatus: 'verified',
      explanation: `Compared "${revCol}" between ${monthNames[m1 - 1]} and ${monthNames[m2 - 1]}${year ? ` in ${year}` : ''} from ${ds.filename}.`,
      dataSources: [ds.filename],
      code: `import pandas as pd

${fileVar} = pd.read_csv("${ds.filename}")

${fileVar}["${dateCol}"] = pd.to_datetime(${fileVar}["${dateCol}"])
${year ? `${fileVar} = ${fileVar}[${fileVar}["${dateCol}"].dt.year == ${year}]\n` : ''}m1 = ${fileVar}[${fileVar}["${dateCol}"].dt.month == ${m1}]["${revCol}"].sum()
m2 = ${fileVar}[${fileVar}["${dateCol}"].dt.month == ${m2}]["${revCol}"].sum()

print(f"${monthNames[m1 - 1]}: {m1}, ${monthNames[m2 - 1]}: {m2}, Diff: {m1 - m2}")`,
      errorMessage: null,
    },
  };
}

function computeTopRegion(ds: Dataset): MatchResult | null {
  const cols = ds.columns.map((c) => c.name);
  const regionCol = findColumn(cols, ['region', 'country', 'state', 'city', 'area', 'zone', 'market']);
  const revCol = findColumn(cols, ['revenue', 'sales', 'amount', 'total', 'growth', 'value']);

  if (!regionCol || !revCol) return null;

  const rows = ds.content;
  const byRegion = new Map<string, number>();
  for (const row of rows) {
    const r = String(row[regionCol] ?? 'Unknown');
    byRegion.set(r, (byRegion.get(r) ?? 0) + toNum(row[revCol]));
  }

  let topRegion = '';
  let topVal = -Infinity;
  for (const [k, v] of byRegion) {
    if (v > topVal) {
      topVal = v;
      topRegion = k;
    }
  }

  const fileVar = ds.filename.replace(/[^a-zA-Z]/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');

  return {
    matched: true,
    result: {
      answer: `${topRegion} (${formatNumber(topVal)})`,
      answerNumeric: topVal,
      verificationStatus: 'verified',
      explanation: `Grouped ${ds.filename} by "${regionCol}" and summed "${revCol}". The region with the highest total is "${topRegion}".`,
      dataSources: [ds.filename],
      code: `import pandas as pd

${fileVar} = pd.read_csv("${ds.filename}")

grouped = ${fileVar}.groupby("${regionCol}")["${revCol}"].sum()

top = grouped.idxmax()
top_value = grouped.max()

print(f"{top}: {top_value}")`,
      errorMessage: null,
    },
  };
}

const MONTH_MAP: Record<string, number> = {
  january: 1, february: 2, march: 3, april: 4, may: 5, june: 6,
  july: 7, august: 8, september: 9, october: 10, november: 11, december: 12,
  jan: 1, feb: 2, mar: 3, apr: 4, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12,
};

export function analyzeQuestion(
  question: string,
  datasets: Dataset[],
): AnalysisResult {
  const q = question.toLowerCase().trim();

  if (datasets.length === 0) {
    return {
      answer: 'I can\'t determine this reliably from the available data.',
      answerNumeric: null,
      verificationStatus: 'cannot_determine',
      explanation: 'No datasets have been uploaded yet. Please upload CSV or Excel files on the Upload Data page before asking questions.',
      dataSources: [],
      code: '',
      errorMessage: 'No data available',
    };
  }

  const yearMatch = q.match(/\b(20\d{2})\b/);
  const year = yearMatch ? parseInt(yearMatch[1]) : null;

  // Total revenue / sales
  if (/\b(total|sum)\b.*\b(revenue|sales|amount|income)\b/.test(q) ||
      /\b(revenue|sales)\b.*\b(total|sum)\b/.test(q)) {
    for (const ds of datasets) {
      const r = computeTotalRevenue(ds, year);
      if (r && r.matched) return r.result;
    }
  }

  // Average order value / average
  if (/\b(average|avg|mean)\b/.test(q)) {
    for (const ds of datasets) {
      const r = computeAverage(ds, year);
      if (r && r.matched) return r.result;
    }
  }

  // Top/highest product
  if (/\b(top|highest|best|max|most)\b.*\b(product|item|profit)\b/.test(q) ||
      /\b(product|item)\b.*\b(top|highest|best)\b/.test(q) ||
      /\b(profit)\b.*\b(top|highest|best|most)\b/.test(q)) {
    for (const ds of datasets) {
      const r = computeTopProduct(ds);
      if (r && r.matched) return r.result;
    }
  }

  // Compare months
  const monthWords = Object.keys(MONTH_MAP);
  const foundMonths = monthWords.filter((m) => new RegExp(`\\b${m}\\b`).test(q));
  if (/\b(compare|comparison|vs|versus|between|difference)\b/.test(q) && foundMonths.length >= 2) {
    const m1 = MONTH_MAP[foundMonths[0]];
    const m2 = MONTH_MAP[foundMonths[1]];
    for (const ds of datasets) {
      const r = computeCompareMonths(ds, m1, m2, year);
      if (r && r.matched) return r.result;
    }
  }

  // Region / area with highest growth
  if (/\b(region|area|zone|country|state)\b.*\b(top|highest|best|max|most|growth)\b/.test(q) ||
      /\b(growth)\b.*\b(region|area|zone|country|state)\b/.test(q)) {
    for (const ds of datasets) {
      const r = computeTopRegion(ds);
      if (r && r.matched) return r.result;
    }
  }

  // Generic count query
  if (/\b(how many|count|number of)\b.*\b(rows|records|orders|transactions|entries)\b/.test(q)) {
    const ds = datasets[0];
    return {
      answer: `${ds.row_count.toLocaleString()} rows`,
      answerNumeric: ds.row_count,
      verificationStatus: 'verified',
      explanation: `Counted all rows in ${ds.filename}. This is a direct row count from the uploaded file.`,
      dataSources: [ds.filename],
      code: `import pandas as pd

df = pd.read_csv("${ds.filename}")

result = len(df)

print(result)`,
      errorMessage: null,
    };
  }

  // Fallback: cannot determine
  return {
    answer: "I can't determine this reliably from the available data.",
    answerNumeric: null,
    verificationStatus: 'cannot_determine',
    explanation: `I could not find the necessary columns in your uploaded datasets to answer this question. The question may require columns like "revenue", "date", "product", or "region" that aren't present. Try rephrasing your question or check the Data Quality page to see what columns are available.`,
    dataSources: datasets.map((d) => d.filename),
    code: '',
    errorMessage: 'No matching columns found for this question type',
  };
}

export function questionToRecord(
  question: string,
  result: AnalysisResult,
): Partial<Question> {
  return {
    question_text: question,
    answer: result.answer,
    answer_numeric: result.answerNumeric,
    verification_status: result.verificationStatus,
    explanation: result.explanation,
    data_sources: result.dataSources,
    code: result.code,
    error_message: result.errorMessage,
  };
}
