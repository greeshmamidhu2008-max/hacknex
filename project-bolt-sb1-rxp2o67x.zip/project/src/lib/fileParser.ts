import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import type { ColumnInfo, ParsedFile } from './types';

const CURRENCY_PATTERN = /\b(USD|EUR|GBP|JPY|CAD|AUD|INR|CNY|\$|€|£|¥|₹)\b/i;
const DATE_PATTERN = /^\d{1,4}[-/\.]\d{1,2}[-/\.]\d{1,4}/;

function inferType(values: unknown[]): ColumnInfo['type'] {
  let numCount = 0;
  let dateCount = 0;
  let boolCount = 0;
  let nonNull = 0;

  for (const v of values) {
    if (v === null || v === undefined || v === '') continue;
    nonNull++;
    const s = String(v).trim();
    if (s === 'true' || s === 'false' || s === 'True' || s === 'False') {
      boolCount++;
    } else if (!isNaN(Number(s)) && s !== '') {
      numCount++;
    } else if (DATE_PATTERN.test(s)) {
      dateCount++;
    }
  }

  if (nonNull === 0) return 'string';
  if (numCount / nonNull > 0.8) return 'number';
  if (dateCount / nonNull > 0.6) return 'date';
  if (boolCount / nonNull > 0.8) return 'boolean';
  if (numCount > 0 && dateCount > 0) return 'mixed';
  return 'string';
}

function analyzeColumns(rows: Record<string, unknown>[]): ColumnInfo[] {
  if (rows.length === 0) return [];
  const colNames = Object.keys(rows[0]);
  return colNames.map((name) => {
    const values = rows.map((r) => r[name]);
    const nonNullValues = values.filter(
      (v) => v !== null && v !== undefined && v !== '',
    );
    const missingCount = values.length - nonNullValues.length;
    const uniqueCount = new Set(nonNullValues.map((v) => String(v))).size;
    const sampleVal = nonNullValues[0] ?? '';
    return {
      name,
      type: inferType(values),
      sample: String(sampleVal).substring(0, 80),
      missingCount,
      uniqueCount,
    };
  });
}

export async function parseFile(file: File): Promise<ParsedFile> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  const fileSize = file.size;

  if (ext === 'csv' || ext === 'txt') {
    return new Promise((resolve, reject) => {
      Papa.parse<Record<string, unknown>>(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: (results) => {
          const rows = results.data;
          const columns = analyzeColumns(rows);
          resolve({
            filename: file.name,
            fileType: 'csv',
            rowCount: rows.length,
            columnCount: columns.length,
            columns,
            rows,
            sheetName: null,
            fileSize,
          });
        },
        error: (err) => reject(err),
      });
    });
  }

  if (ext === 'xlsx' || ext === 'xls') {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: 'array' });
    const sheetName = wb.SheetNames[0] ?? null;
    const sheet = wb.Sheets[sheetName!];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
      raw: true,
      defval: '',
    });
    const columns = analyzeColumns(rows);
    return {
      filename: file.name,
      fileType: 'xlsx',
      rowCount: rows.length,
      columnCount: columns.length,
      columns,
      rows,
      sheetName,
      fileSize,
    };
  }

  throw new Error(`Unsupported file type: .${ext}`);
}

export { CURRENCY_PATTERN, DATE_PATTERN };
