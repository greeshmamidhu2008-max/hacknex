export type DatasetStatus = 'analyzed' | 'error';

export interface ColumnInfo {
  name: string;
  type: 'number' | 'string' | 'date' | 'boolean' | 'mixed';
  sample: string;
  missingCount: number;
  uniqueCount: number;
}

export interface Dataset {
  id: string;
  filename: string;
  file_type: string;
  row_count: number;
  column_count: number;
  columns: ColumnInfo[];
  sheet_name: string | null;
  status: DatasetStatus;
  file_size: number;
  content: Record<string, unknown>[];
  created_at: string;
}

export type IssueType =
  | 'duplicate_rows'
  | 'missing_values'
  | 'currency_mismatch'
  | 'ambiguous_dates'
  | 'inconsistent_keys'
  | 'consistent_data';

export type Severity = 'high' | 'medium' | 'low' | 'info';

export interface DataQualityIssue {
  id: string;
  dataset_id: string;
  type: IssueType;
  severity: Severity;
  title: string;
  explanation: string;
  affected_column: string | null;
  suggested_action: string;
}

export type VerificationStatus =
  | 'verified'
  | 'unverified'
  | 'cannot_determine'
  | 'pending';

export interface Question {
  id: string;
  question_text: string;
  answer: string | null;
  answer_numeric: number | null;
  verification_status: VerificationStatus;
  explanation: string | null;
  data_sources: string[];
  code: string | null;
  error_message: string | null;
  created_at: string;
}

export interface ParsedFile {
  filename: string;
  fileType: string;
  rowCount: number;
  columnCount: number;
  columns: ColumnInfo[];
  rows: Record<string, unknown>[];
  sheetName: string | null;
  fileSize: number;
}
