import type { ColumnInfo, DataQualityIssue, IssueType, ParsedFile, Severity } from './types';

const CURRENCY_SYMBOLS = ['$', '€', '£', '¥', '₹'];
const CURRENCY_CODES = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'INR', 'CNY'];

function detectCurrencies(rows: Record<string, unknown>[], col: ColumnInfo): string[] {
  const found = new Set<string>();
  for (const row of rows) {
    const val = String(row[col.name] ?? '');
    for (const sym of CURRENCY_SYMBOLS) {
      if (val.includes(sym)) found.add(sym);
    }
    for (const code of CURRENCY_CODES) {
      const re = new RegExp(`\\b${code}\\b`, 'i');
      if (re.test(val)) found.add(code);
    }
  }
  return [...found];
}

function detectDateFormats(rows: Record<string, unknown>[], col: ColumnInfo): string[] {
  const formats = new Set<string>();
  for (const row of rows.slice(0, 100)) {
    const val = String(row[col.name] ?? '').trim();
    if (!val) continue;
    if (/^\d{4}-\d{2}-\d{2}/.test(val)) formats.add('ISO (YYYY-MM-DD)');
    else if (/^\d{1,2}\/\d{1,2}\/\d{2,4}/.test(val)) formats.add('US (MM/DD/YYYY)');
    else if (/^\d{1,2}\.\d{1,2}\.\d{2,4}/.test(val)) formats.add('EU (DD.MM.YYYY)');
    else if (/^\d{1,2}-\d{1,2}-\d{2,4}/.test(val)) formats.add('Dash (DD-MM-YYYY)');
  }
  return [...formats];
}

export function detectIssues(parsed: ParsedFile): DataQualityIssue[] {
  const issues: DataQualityIssue[] = [];
  const { rows, columns, filename } = parsed;

  // Duplicate rows
  const seen = new Set<string>();
  let dupCount = 0;
  for (const row of rows) {
    const key = JSON.stringify(row);
    if (seen.has(key)) {
      dupCount++;
    } else {
      seen.add(key);
    }
  }
  if (dupCount > 0) {
    issues.push({
      id: crypto.randomUUID(),
      dataset_id: '',
      type: 'duplicate_rows',
      severity: dupCount > rows.length * 0.05 ? 'high' : 'medium',
      title: 'Duplicate Rows',
      explanation: `${dupCount} duplicate record${dupCount !== 1 ? 's' : ''} detected in ${filename}.`,
      affected_column: null,
      suggested_action:
        'Remove duplicates using pandas.drop_duplicates() or investigate whether they represent legitimate separate transactions.',
    });
  }

  // Missing values per column
  for (const col of columns) {
    if (col.missingCount > 0) {
      const pct = ((col.missingCount / rows.length) * 100).toFixed(1);
      issues.push({
        id: crypto.randomUUID(),
        dataset_id: '',
        type: 'missing_values',
        severity: col.missingCount > rows.length * 0.2 ? 'high' : 'medium',
        title: 'Missing Values',
        explanation: `Column "${col.name}" contains ${col.missingCount} missing value${col.missingCount !== 1 ? 's' : ''} (${pct}% of rows).`,
        affected_column: col.name,
        suggested_action:
          col.missingCount > rows.length * 0.5
            ? `Consider dropping column "${col.name}" or using imputation (mean/median/mode) before analysis.`
            : `Filter out rows with missing "${col.name}" or use imputation appropriate to the data type.`,
      });
    }
  }

  // Currency mismatch
  for (const col of columns) {
    if (col.type === 'number' || col.type === 'string' || col.type === 'mixed') {
      const currencies = detectCurrencies(rows, col);
      if (currencies.length > 1) {
        issues.push({
          id: crypto.randomUUID(),
          dataset_id: '',
          type: 'currency_mismatch',
          severity: 'high',
          title: 'Currency Mismatch',
          explanation: `Column "${col.name}" in ${filename} contains mixed currencies: ${currencies.join(', ')}. Direct summation would produce incorrect totals.`,
          affected_column: col.name,
          suggested_action:
            'Normalize all values to a single currency before aggregation. Identify the currency per row and apply exchange rates.',
        });
      }
    }
  }

  // Ambiguous dates
  for (const col of columns) {
    if (col.type === 'date' || col.type === 'mixed') {
      const formats = detectDateFormats(rows, col);
      if (formats.length > 1) {
        issues.push({
          id: crypto.randomUUID(),
          dataset_id: '',
          type: 'ambiguous_dates',
          severity: 'high',
          title: 'Ambiguous Date Formats',
          explanation: `Column "${col.name}" in ${filename} uses multiple date formats: ${formats.join(', ')}. Dates like 03/05/2024 could be March 5 or May 3.`,
          affected_column: col.name,
          suggested_action:
            'Standardize all dates using pd.to_datetime() with explicit format or dayfirst parameter. Verify a sample before applying globally.',
        });
      }
    }
  }

  // Consistent data (positive signal)
  const allHaveIds = columns.some((c) => /id/i.test(c.name));
  if (allHaveIds && dupCount === 0 && issues.filter((i) => i.type === 'missing_values').length === 0) {
    issues.push({
      id: crypto.randomUUID(),
      dataset_id: '',
      type: 'consistent_data',
      severity: 'info',
      title: 'Consistent Data',
      explanation: `No duplicates or missing values detected in ${filename}. The dataset appears well-structured.`,
      affected_column: null,
      suggested_action: 'No action needed. This dataset is ready for analysis.',
    });
  }

  return issues;
}

export const ISSUE_META: Record<
  IssueType,
  { icon: string; color: string; label: string }
> = {
  duplicate_rows: { icon: 'Copy', color: 'amber', label: 'Duplicate Rows' },
  missing_values: { icon: 'AlertCircle', color: 'orange', label: 'Missing Values' },
  currency_mismatch: { icon: 'DollarSign', color: 'red', label: 'Currency Mismatch' },
  ambiguous_dates: { icon: 'Calendar', color: 'rose', label: 'Ambiguous Dates' },
  inconsistent_keys: { icon: 'Link', color: 'purple', label: 'Inconsistent Keys' },
  consistent_data: { icon: 'CheckCircle', color: 'emerald', label: 'Consistent Data' },
};

export const SEVERITY_META: Record<Severity, { label: string; color: string }> = {
  high: { label: 'High', color: 'red' },
  medium: { label: 'Medium', color: 'amber' },
  low: { label: 'Low', color: 'blue' },
  info: { label: 'Info', color: 'emerald' },
};
