import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase';
import type { Dataset, DataQualityIssue, Question } from './types';

export function useStore() {
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [issues, setIssues] = useState<DataQualityIssue[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);

  const loadAll = useCallback(async () => {
    setLoading(true);
    const [dsRes, qRes] = await Promise.all([
      supabase.from('datasets').select('*').order('created_at', { ascending: false }),
      supabase.from('questions').select('*').order('created_at', { ascending: false }),
    ]);

    const dsData = (dsRes.data ?? []) as Dataset[];
    setDatasets(dsData);

    if (dsData.length > 0) {
      const ids = dsData.map((d) => d.id);
      const issueRes = await supabase
        .from('data_quality_issues')
        .select('*')
        .in('dataset_id', ids)
        .order('severity');
      setIssues((issueRes.data ?? []) as DataQualityIssue[]);
    } else {
      setIssues([]);
    }

    setQuestions((qRes.data ?? []) as Question[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  return { datasets, issues, questions, loading, reload: loadAll };
}
