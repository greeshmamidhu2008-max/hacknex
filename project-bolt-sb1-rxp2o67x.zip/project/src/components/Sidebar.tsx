import {
  LayoutDashboard,
  Upload,
  MessageSquare,
  ShieldCheck,
  AlertTriangle,
  History,
  Settings as SettingsIcon,
  Sparkles,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type Page =
  | 'dashboard'
  | 'upload'
  | 'ask'
  | 'verification'
  | 'quality'
  | 'history'
  | 'settings';

interface SidebarProps {
  current: Page;
  onNavigate: (page: Page) => void;
  fileCount: number;
  issueCount: number;
  questionCount: number;
}

interface NavItem {
  id: Page;
  label: string;
  icon: LucideIcon;
  badge?: number;
}

export function Sidebar({ current, onNavigate, fileCount, issueCount, questionCount }: SidebarProps) {
  const items: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'upload', label: 'Upload Data', icon: Upload, badge: fileCount > 0 ? fileCount : undefined },
    { id: 'ask', label: 'Ask Data', icon: MessageSquare, badge: questionCount > 0 ? questionCount : undefined },
    { id: 'verification', label: 'Verification', icon: ShieldCheck },
    { id: 'quality', label: 'Data Quality', icon: AlertTriangle, badge: issueCount > 0 ? issueCount : undefined },
    { id: 'history', label: 'History', icon: History },
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col h-screen sticky top-0 flex-shrink-0">
      <div className="px-5 py-5 border-b border-slate-200">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
            <Sparkles size={20} className="text-white" />
          </div>
          <div className="min-w-0">
            <h1 className="text-sm font-bold text-slate-900 leading-tight">Proof-Carrying</h1>
            <p className="text-xs text-slate-500 leading-tight">Data Analyst</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {items.map((item) => {
          const active = current === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                active
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Icon size={18} className={active ? 'text-blue-600' : 'text-slate-400'} />
              <span className="flex-1 text-left">{item.label}</span>
              {item.badge !== undefined && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${
                  active ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="px-5 py-4 border-t border-slate-200">
        <div className="text-xs text-slate-400">
          Agentic GenAI · Verification
        </div>
        <div className="text-xs text-slate-300 mt-0.5">v1.0</div>
      </div>
    </aside>
  );
}
