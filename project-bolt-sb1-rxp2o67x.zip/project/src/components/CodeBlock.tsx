import { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface CodeBlockProps {
  code: string;
  language?: string;
}

export function CodeBlock({ code, language = 'python' }: CodeBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!code) return null;

  return (
    <div className="relative rounded-lg overflow-hidden border border-slate-700 bg-[#0d1117]">
      <div className="flex items-center justify-between px-4 py-2 bg-[#161b22] border-b border-slate-700">
        <span className="text-xs font-mono text-slate-400 uppercase tracking-wide">{language}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors"
        >
          {copied ? <Check size={14} /> : <Copy size={14} />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="overflow-x-auto p-4 text-sm leading-relaxed">
        <code className="font-mono text-slate-200">{highlightPython(code)}</code>
      </pre>
    </div>
  );
}

function highlightPython(code: string): React.ReactNode {
  const keywords = /\b(import|from|def|class|return|if|else|elif|for|while|in|not|and|or|is|None|True|False|print|lambda|with|as|try|except|finally|raise|yield|global|nonlocal|pass|break|continue|del|assert|async|await)\b/g;
  const strings = /(["'])[^"']*\1/g;
  const comments = /#.*$/gm;
  const numbers = /\b\d+\.?\d*\b/g;

  const lines = code.split('\n');
  return lines.map((line, lineIdx) => {
    const parts: React.ReactNode[] = [];
    let remaining = line;

    // Handle comments first
    const commentMatch = remaining.match(/#.*$/);
    let commentPart: string | null = null;
    if (commentMatch && commentMatch.index !== undefined) {
      commentPart = remaining.substring(commentMatch.index);
      remaining = remaining.substring(0, commentMatch.index);
    }

    // Tokenize remaining
    const tokenRegex = /(["'])[^"']*\1|\b\d+\.?\d*\b|\b(import|from|def|class|return|if|else|elif|for|while|in|not|and|or|is|None|True|False|print|lambda|with|as|try|except|finally|raise|yield|global|nonlocal|pass|break|continue|del|assert|async|await)\b/g;
    let lastIndex = 0;
    let match;
    let partKey = 0;

    while ((match = tokenRegex.exec(remaining)) !== null) {
      if (match.index > lastIndex) {
        parts.push(<span key={`t-${lineIdx}-${partKey++}`}>{remaining.substring(lastIndex, match.index)}</span>);
      }
      const token = match[0];
      if (/^["']/.test(token)) {
        parts.push(<span key={`s-${lineIdx}-${partKey++}`} className="text-emerald-300">{token}</span>);
      } else if (/^\d/.test(token)) {
        parts.push(<span key={`n-${lineIdx}-${partKey++}`} className="text-amber-300">{token}</span>);
      } else {
        parts.push(<span key={`k-${lineIdx}-${partKey++}`} className="text-sky-400 font-medium">{token}</span>);
      }
      lastIndex = match.index + token.length;
    }

    if (lastIndex < remaining.length) {
      parts.push(<span key={`r-${lineIdx}-${partKey++}`}>{remaining.substring(lastIndex)}</span>);
    }

    if (commentPart) {
      parts.push(<span key={`c-${lineIdx}`} className="text-slate-500 italic">{commentPart}</span>);
    }

    return (
      <span key={lineIdx}>
        {parts}
        {lineIdx < lines.length - 1 && '\n'}
      </span>
    );
  });
}
