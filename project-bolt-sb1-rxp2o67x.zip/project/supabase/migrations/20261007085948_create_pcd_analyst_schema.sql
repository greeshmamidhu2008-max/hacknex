/*
# Proof-Carrying Data Analyst — Schema

## Purpose
Stores uploaded dataset metadata, detected data-quality issues,
questions asked by the user, AI-generated answers with verification
code, and application settings. Single-tenant (no auth) so policies
are open to anon + authenticated.

## New Tables

### datasets
- id (uuid, PK)
- filename (text) — original file name
- file_type (text) — csv or xlsx
- row_count (int) — number of data rows
- column_count (int) — number of columns
- columns (jsonb) — array of {name, type, sample} objects
- sheet_name (text, nullable) — for Excel files with multiple sheets
- status (text) — 'analyzed' | 'error'
- file_size (bigint) — size in bytes
- content (jsonb) — serialized rows (up to 200 sampled + full schema)
- created_at (timestamptz)

### data_quality_issues
- id (uuid, PK)
- dataset_id (uuid, FK -> datasets, cascade delete)
- type (text) — duplicate_rows | missing_values | currency_mismatch | ambiguous_dates | inconsistent_keys | consistent_data
- severity (text) — high | medium | low | info
- title (text)
- explanation (text)
- affected_column (text, nullable)
- suggested_action (text)

### questions
- id (uuid, PK)
- question_text (text)
- answer (text, nullable)
- answer_numeric (numeric, nullable)
- verification_status (text) — verified | unverified | cannot_determine | pending
- explanation (text, nullable)
- data_sources (jsonb, nullable) — array of dataset filenames used
- code (text, nullable) — generated Python verification code
- error_message (text, nullable)
- created_at (timestamptz)

### settings
- id (uuid, PK)
- key (text, unique)
- value (jsonb)

## Security
- RLS enabled on all tables.
- Single-tenant app (no sign-in) — all CRUD open to anon + authenticated.
*/

CREATE TABLE IF NOT EXISTS datasets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  filename text NOT NULL,
  file_type text NOT NULL DEFAULT 'csv',
  row_count integer NOT NULL DEFAULT 0,
  column_count integer NOT NULL DEFAULT 0,
  columns jsonb NOT NULL DEFAULT '[]'::jsonb,
  sheet_name text,
  status text NOT NULL DEFAULT 'analyzed',
  file_size bigint NOT NULL DEFAULT 0,
  content jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE datasets ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_datasets" ON datasets;
CREATE POLICY "anon_select_datasets" ON datasets FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_datasets" ON datasets;
CREATE POLICY "anon_insert_datasets" ON datasets FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_datasets" ON datasets;
CREATE POLICY "anon_update_datasets" ON datasets FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_datasets" ON datasets;
CREATE POLICY "anon_delete_datasets" ON datasets FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS data_quality_issues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dataset_id uuid NOT NULL REFERENCES datasets(id) ON DELETE CASCADE,
  type text NOT NULL,
  severity text NOT NULL DEFAULT 'medium',
  title text NOT NULL,
  explanation text NOT NULL DEFAULT '',
  affected_column text,
  suggested_action text NOT NULL DEFAULT ''
);

ALTER TABLE data_quality_issues ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_issues" ON data_quality_issues;
CREATE POLICY "anon_select_issues" ON data_quality_issues FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_issues" ON data_quality_issues;
CREATE POLICY "anon_insert_issues" ON data_quality_issues FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_issues" ON data_quality_issues;
CREATE POLICY "anon_update_issues" ON data_quality_issues FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_issues" ON data_quality_issues;
CREATE POLICY "anon_delete_issues" ON data_quality_issues FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_text text NOT NULL,
  answer text,
  answer_numeric numeric,
  verification_status text NOT NULL DEFAULT 'pending',
  explanation text,
  data_sources jsonb DEFAULT '[]'::jsonb,
  code text,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_questions" ON questions;
CREATE POLICY "anon_select_questions" ON questions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_questions" ON questions;
CREATE POLICY "anon_insert_questions" ON questions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_questions" ON questions;
CREATE POLICY "anon_update_questions" ON questions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_questions" ON questions;
CREATE POLICY "anon_delete_questions" ON questions FOR DELETE TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL DEFAULT '{}'::jsonb
);

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_settings" ON settings;
CREATE POLICY "anon_select_settings" ON settings FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_settings" ON settings;
CREATE POLICY "anon_insert_settings" ON settings FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_settings" ON settings;
CREATE POLICY "anon_update_settings" ON settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_settings" ON settings;
CREATE POLICY "anon_delete_settings" ON settings FOR DELETE TO anon, authenticated USING (true);